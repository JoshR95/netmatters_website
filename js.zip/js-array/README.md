# js-array
javaScript array asssessment for netmatters
